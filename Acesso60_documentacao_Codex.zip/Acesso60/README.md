# Acesso60

**Estado do código:** não auditado nesta entrega documental. Este pacote contém documentação, **não** o aplicativo Android nem um APK.

O **Acesso60** é um projeto acadêmico de aplicativo Android assistivo por voz, voltado principalmente a pessoas idosas. Planeja reconhecer comandos, interpretar intenções, aplicar validações e política de risco, executar ações autorizadas e apresentar feedback acessível.

## Contexto técnico planejado
- Kotlin e Jetpack Compose.
- `SpeechRecognizer` (entrada de voz); `TextToSpeech` (feedback).
- `AccessibilityService` e APIs Android para ações permitidas.
- Núcleo com `CommandInterpreter`, `CommandValidator`, `RiskPolicy`, `CommandRouter` e executor.
- Testes com JUnit e, conforme implantação, Compose UI Test, Android Lint, ktlint, detekt e Kover.

## Documentação
Comece por [`docs/INDEX.md`](docs/INDEX.md). Agentes devem consultar [`AGENTS.md`](AGENTS.md).

## RT03
O enunciado acadêmico prevê entrega em **28/10/2026**: documentação consolidada, protótipo de alta fidelidade ou versão alfa/beta, testes unitários basais, evidências de validação/tratamento de erros, relatório de uso de IA e roteiro de banca. Consulte `docs/milestones/rt03-plan.md`.

## Como executar
**Pendente de auditoria do repositório.** Não há instruções de build comprovadas neste pacote documental. Quando o projeto Android e o Gradle Wrapper forem verificados, registrar aqui os passos de compilação, ambiente, permissões e execução de testes.

## Fontes do conteúdo
- Conversas de planejamento do Acesso60, consolidadas até 26/10/2026.
- Enunciado da UC Qualidade de Software, apresentado anteriormente na conversa (RT01–RT04).
- Instruções oficiais do Codex sobre `AGENTS.md`: https://learn.chatgpt.com/docs/agent-configuration/agents-md

**Atenção:** o repositório mencionado é `https://github.com/retrocyborg/Acesso`, mas seu estado atual não foi inspecionado para produzir estes arquivos.
