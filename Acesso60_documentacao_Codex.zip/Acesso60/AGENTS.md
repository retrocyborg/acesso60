# Instruções para agentes — Acesso60

## Objetivo do repositório
Aplicativo assistivo Android, com comandos de voz voltados especialmente a pessoas idosas. **Este arquivo governa o comportamento do agente; não atesta funcionalidades existentes.**

## Regras permanentes
1. Antes de editar, inspecione o repositório e identifique o estado real dos arquivos. Nunca confunda `planejado`, `implementado` e `verificado`.
2. Preserve a separação `SpeechToText → Interpretation → Validation → RiskPolicy → Routing → Execution → Verification → Feedback`; adapte-a quando o código exigir, documentando decisões.
3. Não encaminhe texto transcrito diretamente para ações do Android. Qualquer origem de comando, inclusive IA, percorre validação e autorização.
4. Não execute ações sensíveis (envio, exclusão, exposição de dados) sem confirmação/autorização contextual. Falha deve resultar em comportamento seguro.
5. Mantenha a lógica de domínio isolada de Android SDK, UI e bibliotecas de reconhecimento de voz; favoreça interfaces e testes com fakes.
6. Ao alterar comportamento, atualize testes, requisitos afetados e documentação pertinente. Não marque teste como aprovado sem executá-lo.
7. Não acrescente dependências, permissões ou acesso a dados sensíveis sem justificativa documentada.
8. Preserve acessibilidade da interface: texto legível, alvos de toque adequados, rótulos semânticos e feedback claro.
9. Evite registrar ou armazenar por padrão conteúdo de voz, transcrições, mensagens e dados lidos da tela; proteja logs e segredos.
10. Siga escopo RT03 definido em `docs/milestones/rt03-plan.md`; não antecipe funcionalidades RT04 sem solicitação.

## Leituras por tarefa
- Sumário de documentos: `docs/INDEX.md`.
- Problema e escopo: `docs/project/overview.md`.
- Pipeline e módulos: `docs/project/architecture.md`.
- Requisitos e seus níveis de certeza: `docs/engineering/requirements.md`.
- Regras acadêmicas e QA: `docs/standards/qa-rules.md`.
- Testes: `docs/engineering/testing-strategy.md`.
- Estado comprovado da RT03: `docs/milestones/rt03-status.md`.

## Protocolo de entrega de cada tarefa
1. Descrever arquivos encontrados e requisitos envolvidos.
2. Planejar mudança mínima; preservar API/comportamento quando possível.
3. Implementar e adicionar testes aplicáveis.
4. Executar verificações disponíveis ou registrar exatamente o bloqueio.
5. Relatar arquivos alterados, comandos executados, resultados, riscos e lacunas.

## Revisão de código
Sinalize execução sem validação, bypass de política de risco, confiança em resposta de LLM, permissões excessivas, dados pessoais em logs, UI sem acessibilidade e alegações de testes sem evidência.
