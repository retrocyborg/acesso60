package com.acesso60.messaging

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/** Descobre o telefone de um destinatário a partir do que o usuário falou. */
interface ContactResolver {
    /** Telefone do contato, ou `null` se não achou, se há mais de um candidato ou se falta permissão. */
    fun findPhone(spokenRecipient: String): String?
}

/**
 * Procura na agenda do aparelho. Exige a permissão READ_CONTACTS; sem ela devolve `null`
 * e o envio cai no modo manual. A comparação de nomes é feita em memória por [ContactMatcher]
 * (ignora acento e caixa, coisa que o LIKE do SQLite não faz).
 */
class AndroidContactResolver(context: Context) : ContactResolver {
    private val appContext = context.applicationContext

    override fun findPhone(spokenRecipient: String): String? {
        ContactMatcher.dictatedNumber(spokenRecipient)?.let { return it }
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }
        return try {
            ContactMatcher.findPhone(spokenRecipient, loadContacts())
        } catch (_: SecurityException) {
            null
        } catch (_: RuntimeException) {
            null
        }
    }

    private fun loadContacts(): List<ContactEntry> {
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
        )
        val result = mutableListOf<ContactEntry>()
        appContext.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            null,
        )?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val typeIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.TYPE)
            if (nameIndex < 0 || numberIndex < 0) return emptyList()
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameIndex) ?: continue
                val number = cursor.getString(numberIndex) ?: continue
                val isMobile = typeIndex >= 0 &&
                    cursor.getInt(typeIndex) == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                result += ContactEntry(name, number, isMobile)
            }
        }
        return result
    }
}
