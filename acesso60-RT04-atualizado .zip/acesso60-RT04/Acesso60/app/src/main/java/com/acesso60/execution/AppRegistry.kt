package com.acesso60.execution

interface AppRegistry {
    fun resolve(alias: String): AppDefinition?
}

/**
 * Registry para a allowlist de aplicativos.
 *
 * Ordem de resolução de um nome falado:
 * 1. alias das definições ([AppDefinitionProvider] ou lista estática), ignorando caixa e acentos;
 * 2. nome visível dos APKs instalados no aparelho ([InstalledAppsSource]), de forma tolerante
 *    (ver [AppNameMatcher]). Isso permite abrir QUALQUER app instalado por voz, sem cadastro prévio.
 *
 * Se a definição encontrada aponta para um pacote que NÃO está instalado (ex.: o app de mensagens do
 * fabricante tem outro pacote), tenta-se o nome entre os instalados antes de desistir.
 *
 * Quando instanciado com um [AppDefinitionProvider], resolve consultas dinamicamente
 * para refletir novos aliases adicionados em tempo de execução sem necessitar reiniciar o app.
 */
class StaticAppRegistry(
    private val provider: AppDefinitionProvider?,
    private val staticDefinitions: List<AppDefinition> = emptyList(),
    private val installedApps: InstalledAppsSource? = null,
) : AppRegistry {

    constructor(definitions: List<AppDefinition>) : this(
        provider = null,
        staticDefinitions = definitions,
    ) {
        validate(definitions)
    }

    /**
     * Com provider não há validação de duplicidade: aliases vêm do JSON e do usuário (por voz) e uma
     * colisão não pode derrubar o app na abertura. Em colisão vale a primeira definição.
     */
    constructor(provider: AppDefinitionProvider) : this(
        provider = provider,
        staticDefinitions = emptyList(),
        installedApps = null,
    )

    constructor(provider: AppDefinitionProvider, installedApps: InstalledAppsSource) : this(
        provider = provider,
        staticDefinitions = emptyList(),
        installedApps = installedApps,
    )

    private fun validate(defs: List<AppDefinition>) {
        val entries = defs.flatMap { definition ->
            definition.aliases.map { alias -> AppNameMatcher.normalize(alias) to definition }
        }
        require(entries.map { it.first }.toSet().size == entries.size) {
            "Aliases duplicados no registry de aplicativos."
        }
    }

    override fun resolve(alias: String): AppDefinition? {
        val normalized = AppNameMatcher.normalize(alias)
        if (normalized.isEmpty()) return null

        val defs = provider?.provide() ?: staticDefinitions
        val byAlias = defs.firstOrNull { definition ->
            definition.aliases.any { AppNameMatcher.normalize(it) == normalized }
        }

        val installed = installedApps?.list()
        if (installed == null) return byAlias

        if (byAlias != null && installed.any { it.packageName == byAlias.packageName }) return byAlias

        val byLabel = AppNameMatcher.bestMatch(alias, installed)?.toDefinition()
        // Definição conhecida mas não instalada e sem equivalente instalado: devolve a definição,
        // para o launcher informar "não instalado" em vez de "app desconhecido".
        return byLabel ?: byAlias
    }

    private fun InstalledApp.toDefinition() = AppDefinition(
        id = label,
        packageName = packageName,
        aliases = setOf(label),
    )
}
