package com.acesso60.accessibility

/**
 * Pedido de "enviar sozinho" feito pelo [com.acesso60.messaging.MessageLauncher] e consumido pelo
 * serviço de acessibilidade.
 *
 * Segurança: o clique só acontece se (1) houve um pedido do próprio Acesso60 há poucos segundos,
 * (2) a janela em primeiro plano é a do app de mensagens esperado e (3) um único clique por pedido.
 * Sem pedido armado, o serviço não clica em nada.
 */
object AutoSendRequests {
    const val DEFAULT_TIMEOUT_MS = 15_000L

    /** Relógio injetável para testes. */
    @Volatile
    var clock: () -> Long = { System.nanoTime() / 1_000_000L }

    private val lock = Any()
    private var armedPackage: String? = null
    private var deadline: Long = 0L

    fun arm(packageName: String, timeoutMs: Long = DEFAULT_TIMEOUT_MS) = synchronized(lock) {
        armedPackage = packageName
        deadline = clock() + timeoutMs
    }

    /** Há pedido ativo para esta janela? Pedido vencido é descartado. */
    fun isArmedFor(packageName: String?): Boolean = synchronized(lock) {
        val armed = armedPackage ?: return false
        if (clock() > deadline) {
            armedPackage = null
            return false
        }
        packageName == armed
    }

    /** Marca o pedido como cumprido (um clique por pedido). */
    fun complete() = cancel()

    fun cancel() = synchronized(lock) {
        armedPackage = null
    }
}
