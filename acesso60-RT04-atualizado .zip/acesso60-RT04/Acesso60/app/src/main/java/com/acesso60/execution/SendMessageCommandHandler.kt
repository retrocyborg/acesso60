package com.acesso60.execution

import br.com.acesso60.core.executor.CommandHandler
import br.com.acesso60.core.messaging.MessagingAppCatalog
import br.com.acesso60.core.model.Command
import br.com.acesso60.core.model.ExecutionResult
import com.acesso60.messaging.MessageLaunchResult
import com.acesso60.messaging.MessageLauncher

/**
 * Envia a mensagem pelo app escolhido: abre a conversa com o texto pronto e, quando o contato foi
 * identificado e o serviço de acessibilidade está ativo, o botão "Enviar" é tocado automaticamente.
 *
 * O sucesso nunca é "verificado": o app externo é quem entrega a mensagem, e o texto devolvido ao
 * usuário diz exatamente o que aconteceu (enviando sozinho, contato não encontrado ou envio manual).
 * Só deve receber comandos já validados e classificados pelo núcleo.
 */
class SendMessageCommandHandler(
    private val launcher: MessageLauncher,
) : CommandHandler {

    override fun supports(command: Command): Boolean = command is Command.SendMessage

    override fun handle(command: Command): ExecutionResult {
        val send = command as? Command.SendMessage ?: return ExecutionResult.Unavailable
        val appName = MessagingAppCatalog.findById(send.appId)?.displayName ?: return ExecutionResult.Unavailable
        return when (val result = launcher.launch(send)) {
            is MessageLaunchResult.Started -> ExecutionResult.Success(describe(result, send, appName))
            MessageLaunchResult.NotInstalled -> ExecutionResult.Unavailable
            is MessageLaunchResult.Failed -> ExecutionResult.Failure("Não foi possível abrir o $appName.")
        }
    }

    private fun describe(result: MessageLaunchResult.Started, send: Command.SendMessage, appName: String): String =
        when {
            result.autoSend -> "Enviando mensagem para ${send.recipient} no $appName."
            result.contactFound -> "Abri o $appName com a mensagem pronta para ${send.recipient}. " +
                "Ative o serviço de acessibilidade do Acesso60 para enviar sozinho; por enquanto, toque em enviar."
            else -> "Não encontrei ${send.recipient} nos contatos. Abri o $appName com a mensagem pronta. " +
                "Escolha ${send.recipient} e toque em enviar."
        }
}
