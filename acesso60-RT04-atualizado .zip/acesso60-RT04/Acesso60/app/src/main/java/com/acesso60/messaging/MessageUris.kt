package com.acesso60.messaging

import java.net.URLEncoder

/** Formatação de telefone e montagem das URLs de conversa. Puro Kotlin, sem Android. */
object MessageUris {

    /**
     * Converte um telefone da agenda para só dígitos com código do país (formato que o WhatsApp exige).
     * Sem "+" nem "00", assume o país padrão ([defaultCountryCode], Brasil) para números nacionais de 10 ou 11 dígitos.
     */
    fun toInternationalDigits(raw: String, defaultCountryCode: String = "55"): String? {
        val trimmed = raw.trim()
        var digits = trimmed.filter { it.isDigit() }
        if (digits.length < MIN_DIGITS) return null
        if (trimmed.startsWith("+")) return digits
        if (digits.startsWith("00")) return digits.removePrefix("00")
        if (digits.startsWith("0") && digits.length > NATIONAL_MAX_DIGITS) digits = digits.trimStart('0')
        return if (digits.length <= NATIONAL_MAX_DIGITS) defaultCountryCode + digits else digits
    }

    /** Texto seguro para query string (espaço vira %20; o "+" do URLEncoder não é entendido por todos os apps). */
    fun encode(text: String): String = URLEncoder.encode(text, "UTF-8").replace("+", "%20")

    fun whatsappChat(phoneDigits: String, text: String): String =
        "https://api.whatsapp.com/send?phone=$phoneDigits&text=${encode(text)}"

    private const val MIN_DIGITS = 8
    private const val NATIONAL_MAX_DIGITS = 11
}
