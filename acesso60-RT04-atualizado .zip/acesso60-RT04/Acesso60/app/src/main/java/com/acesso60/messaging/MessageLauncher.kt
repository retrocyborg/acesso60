package com.acesso60.messaging

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony
import br.com.acesso60.core.messaging.MessagingAppCatalog
import br.com.acesso60.core.messaging.MessagingAppOption
import br.com.acesso60.core.model.Command
import com.acesso60.accessibility.AutoSendRequests

/**
 * Monta o Intent de envio.
 *
 * Com o telefone do destinatário ([phone]) a conversa já abre no contato certo com o texto preenchido:
 * - WhatsApp / WhatsApp Business: `https://api.whatsapp.com/send?phone=...&text=...`
 * - SMS: `smsto:<telefone>` com `sms_body`
 *
 * Sem telefone (ou para apps sem link de conversa, como Telegram e Signal) o app abre só com o TEXTO
 * pronto via ACTION_SEND e a pessoa escolhe o contato. O nome do destinatário NÃO entra no corpo da mensagem.
 */
object MessageIntentFactory {
    fun build(command: Command.SendMessage, app: MessagingAppOption, phone: String? = null): Intent {
        val digits = phone?.let { MessageUris.toInternationalDigits(it) }
        return when {
            app.id == MessagingAppCatalog.SMS -> {
                // Sem setPackage: o app de SMS padrão varia por fabricante (Google, Samsung etc.).
                val target = (digits?.let { "+$it" } ?: phone?.filter { c -> c.isDigit() || c == '+' }).orEmpty()
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$target")).apply {
                    putExtra("sms_body", command.messageText)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            digits != null && isWhatsApp(app) ->
                Intent(Intent.ACTION_VIEW, Uri.parse(MessageUris.whatsappChat(digits, command.messageText))).apply {
                    setPackage(app.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            else -> Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, command.messageText)
                setPackage(app.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
    }

    /** O clique automático em "Enviar" só é seguro quando a conversa já abriu no contato identificado. */
    fun supportsAutoSend(app: MessagingAppOption): Boolean =
        app.id == MessagingAppCatalog.SMS || isWhatsApp(app)

    private fun isWhatsApp(app: MessagingAppOption): Boolean =
        app.id == MessagingAppCatalog.WHATSAPP || app.id == MessagingAppCatalog.WHATSAPP_BUSINESS
}

/** Resultado de abrir o app de mensagens. */
sealed interface MessageLaunchResult {
    /**
     * @param autoSend `true` se o serviço de acessibilidade vai tocar em "Enviar" sozinho.
     * @param contactFound `true` se o destinatário foi identificado (conversa aberta direto no contato).
     */
    data class Started(val autoSend: Boolean, val contactFound: Boolean) : MessageLaunchResult
    data object NotInstalled : MessageLaunchResult
    data class Failed(val reason: String) : MessageLaunchResult
}

interface MessageLauncher {
    fun launch(command: Command.SendMessage): MessageLaunchResult
}

class AndroidMessageLauncher(
    private val context: Context,
    private val contacts: ContactResolver = AndroidContactResolver(context),
    private val autoSendAvailable: () -> Boolean = { com.acesso60.accessibility.Acesso60AccessibilityService.isConnected() },
) : MessageLauncher {

    override fun launch(command: Command.SendMessage): MessageLaunchResult {
        val app = MessagingAppCatalog.findById(command.appId)
            ?: return MessageLaunchResult.Failed("Aplicativo de mensagens não permitido.")
        if (app.id != MessagingAppCatalog.SMS &&
            context.packageManager.getLaunchIntentForPackage(app.packageName) == null
        ) {
            return MessageLaunchResult.NotInstalled
        }

        val phone = contacts.findPhone(command.recipient)
        val contactFound = phone != null
        // Pacote da janela onde o "Enviar" será tocado; sem ele (ex.: SMS sem app padrão) não há envio automático.
        val autoSendPackage = if (contactFound && MessageIntentFactory.supportsAutoSend(app) && autoSendAvailable()) {
            resolveAutoSendPackage(app)
        } else {
            null
        }
        val autoSend = autoSendPackage != null

        return try {
            // Arma antes de abrir: o primeiro evento de janela do app já pode trazer o botão Enviar.
            if (autoSendPackage != null) AutoSendRequests.arm(autoSendPackage)
            context.startActivity(MessageIntentFactory.build(command, app, phone))
            MessageLaunchResult.Started(autoSend = autoSend, contactFound = contactFound)
        } catch (_: ActivityNotFoundException) {
            AutoSendRequests.cancel()
            MessageLaunchResult.NotInstalled
        } catch (_: SecurityException) {
            AutoSendRequests.cancel()
            MessageLaunchResult.Failed("Permissão insuficiente para abrir o aplicativo.")
        }
    }

    /** SMS: o app padrão varia por fabricante, então pergunta ao sistema qual é. */
    private fun resolveAutoSendPackage(app: MessagingAppOption): String? =
        if (app.id == MessagingAppCatalog.SMS) {
            Telephony.Sms.getDefaultSmsPackage(context)
        } else {
            app.packageName
        }
}
