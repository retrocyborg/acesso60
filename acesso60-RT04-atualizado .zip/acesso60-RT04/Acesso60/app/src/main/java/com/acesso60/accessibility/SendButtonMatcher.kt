package com.acesso60.accessibility

import java.text.Normalizer

/**
 * Decide se um nó da tela é o botão "Enviar" de um app de mensagens. Puro Kotlin, sem Android.
 *
 * Reconhece pelo id do recurso (WhatsApp: `:id/send`; Google Mensagens: `:id/send_message_button_icon`)
 * ou pelo rótulo de acessibilidade ("Enviar", "Enviar SMS", "Send"...). Comparação exata, para não
 * clicar em coisas como "Enviar arquivo" ou "Enviar localização".
 */
object SendButtonMatcher {
    private val idSuffixes = setOf(
        ":id/send",
        ":id/send_button",
        ":id/send_message_button",
        ":id/send_message_button_icon",
        ":id/send_sms_button",
        ":id/composer_send",
    )
    private val labels = setOf(
        "enviar", "enviar sms", "enviar mensagem", "enviar mms",
        "send", "send sms", "send message", "send mms",
    )

    fun matches(viewId: String?, text: String?, contentDescription: String?): Boolean {
        if (viewId != null && idSuffixes.any { viewId.endsWith(it) }) return true
        return normalize(contentDescription) in labels || normalize(text) in labels
    }

    private fun normalize(value: String?): String {
        if (value.isNullOrBlank()) return ""
        val decomposed = Normalizer.normalize(value.trim().lowercase(), Normalizer.Form.NFD)
        return decomposed.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
    }
}
