package com.acesso60.execution

import android.content.Context
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import timber.log.Timber

/**
 * Provider que lê a lista de aplicativos a partir de um arquivo JSON.
 * A lista base vem dos assets (`app/src/main/assets/app_definitions.json`) e é mesclada com
 * `context.filesDir/app_definitions.json` (persistência mutável dos aliases do usuário).
 *
 * Implementa `MutableAppDefinitionProvider` para permitir que novos
 * aliases sejam adicionados e persistidos.
 *
 * Thread‑safety: todas as leituras e gravações do cache são protegidas por
 * um `ReentrantLock`. O provedor pode ser usado a partir de qualquer thread.
 */
class JsonAppDefinitionProvider(
    private val context: Context,
    private val assetPath: String = "app_definitions.json",
    val persistDelayMs: Long = 500L // debounce interval (default 500 ms)
) : MutableAppDefinitionProvider {

    private val json = Json { prettyPrint = true }
    private val lock = ReentrantLock()
    private var cache: MutableList<AppDefinition> = mutableListOf()
    private var persistJob: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Exposição pública para os testes
    val apps: List<AppDefinition>
        get() = lock.withLock { cache.toList() }

    companion object {
        /** Retorna o arquivo interno onde o JSON de definição de apps é armazenado. */
        fun storageFile(context: Context): File =
            File(context.filesDir, "app_definitions.json")

        /** Factory suspensa que cria a instância garantindo que o cache esteja carregado. */
        suspend fun create(context: Context, assetPath: String = "app_definitions.json"): JsonAppDefinitionProvider {
            return try {
                val provider = JsonAppDefinitionProvider(context, assetPath)
                try {
                    val loaded = provider.loadFromStorage()
                    provider.lock.withLock { provider.cache = loaded.toMutableList() }
                } catch (e: Exception) {
                    Timber.e(e, "[JsonAppDefinitionProvider] failed to initialise cache, falling back to empty list")
                    provider.lock.withLock { provider.cache = mutableListOf() }
                }
                provider
            } catch (e: Exception) {
                Timber.e(e, "[JsonAppDefinitionProvider] unexpected error during creation, returning empty provider")
                val fallback = JsonAppDefinitionProvider(context, assetPath)
                fallback.lock.withLock { fallback.cache = mutableListOf() }
                fallback
            }
        }
    }

    /**
     * Carrega os assets (lista base, que cresce a cada versão do app) e mescla por cima o arquivo
     * salvo em `filesDir` (aliases que o usuário adicionou por voz). Assim, atualizar o app traz os
     * apps novos do asset sem perder os aliases do usuário; antes, um arquivo salvo escondia o asset
     * para sempre.
     */
    private suspend fun loadFromStorage(): List<AppDefinition> = withContext(Dispatchers.IO) {
        val base = readAssets()
        val saved = readStorage()
        mergeDefinitions(base, saved)
    }

    private fun readAssets(): List<AppDefinition> = try {
        context.assets.open(assetPath).bufferedReader().use { reader ->
            parseDefinitions(reader.readText(), "assets")
        }
    } catch (e: Exception) {
        Timber.e(e, "[JsonAppDefinitionProvider] error accessing asset file")
        emptyList()
    }

    private fun readStorage(): List<AppDefinition> = try {
        val file = File(context.filesDir, "app_definitions.json")
        if (file.exists()) parseDefinitions(file.readText(), "storage") else emptyList()
    } catch (e: Exception) {
        Timber.e(e, "[JsonAppDefinitionProvider] error accessing storage file")
        emptyList()
    }

    private fun parseDefinitions(source: String, origin: String): List<AppDefinition> {
        if (source.isBlank()) {
            Timber.w("[JsonAppDefinitionProvider] $origin file is blank")
            return emptyList()
        }
        return try {
            json.decodeFromString<List<AppDefinition>>(source)
        } catch (e: Exception) {
            Timber.e("[JsonAppDefinitionProvider] Failed to parse app definitions from $origin: ${e.message}", e)
            emptyList()
        }
    }

    /** Une por `id`: pacote do asset (mais atual) e aliases de ambos. Entradas só do usuário são mantidas. */
    private fun mergeDefinitions(base: List<AppDefinition>, saved: List<AppDefinition>): List<AppDefinition> {
        val merged = LinkedHashMap<String, AppDefinition>()
        base.forEach { merged[it.id] = it }
        saved.forEach { user ->
            val existing = merged[user.id]
            merged[user.id] = if (existing == null) user else existing.copy(aliases = existing.aliases + user.aliases)
        }
        return merged.values.toList()
    }

    /** Persiste a lista inteira no arquivo interno. */
    private suspend fun persistNow() = withContext(Dispatchers.IO) {
        try {
            val file = File(context.filesDir, "app_definitions.json")
            // Ensure directory exists
            file.parentFile?.mkdirs()
            val snapshot = lock.withLock { cache.toList() }
            file.writeText(json.encodeToString(snapshot))
        } catch (e: Exception) {
            Timber.e("[JsonAppDefinitionProvider] erro ao gravar JSON: ${e.message}", e)
        }
    }

    /** Agenda a persistência usando debounce. */
    private fun schedulePersist() {
        lock.withLock {
            persistJob?.cancel()
            persistJob = scope.launch {
                delay(persistDelayMs)
                persistNow()
            }
        }
    }

    // Interface implementations
    override fun provide(): List<AppDefinition> = lock.withLock { cache.toList() }

    override suspend fun addOrUpdate(app: AppDefinition) {
        lock.withLock {
            val index = cache.indexOfFirst { it.id == app.id }
            if (index >= 0) {
                val existing = cache[index]
                val merged = existing.copy(aliases = existing.aliases + app.aliases)
                cache[index] = merged
            } else {
                cache.add(app)
            }
        }
        schedulePersist()
    }

    /** Close the provider and cancel any pending jobs. */
    fun close() {
        lock.withLock {
            persistJob?.cancel()
            scope.cancel()
        }
    }
}
