package com.acesso60.execution

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build

/** Aplicativo instalado que aparece na tela inicial do aparelho (tem ícone de lançamento). */
data class InstalledApp(val label: String, val packageName: String)

/** Fonte da lista de apps instalados. Interface para que o registro seja testável sem Android. */
interface InstalledAppsSource {
    fun list(): List<InstalledApp>
}

/**
 * Lê os APKs instalados no aparelho via [PackageManager] (ACTION_MAIN + CATEGORY_LAUNCHER),
 * extraindo o nome visível e o `packageName` de cada um.
 *
 * No Android 11+ isso só enxerga os outros apps por causa do bloco `<queries>` do AndroidManifest.
 * A lista fica em cache por [cacheTtlMs] para não varrer o sistema a cada comando de voz, e é relida
 * quando o cache vence (app recém-instalado passa a ser reconhecido sem reiniciar o Acesso60).
 */
class AndroidInstalledAppsSource(
    context: Context,
    private val cacheTtlMs: Long = 30_000L,
    private val clock: () -> Long = { System.currentTimeMillis() },
) : InstalledAppsSource {
    private val appContext = context.applicationContext
    private val lock = Any()
    private var cache: List<InstalledApp> = emptyList()
    private var loadedAt: Long = Long.MIN_VALUE

    override fun list(): List<InstalledApp> = synchronized(lock) {
        val now = clock()
        if (loadedAt == Long.MIN_VALUE || now - loadedAt >= cacheTtlMs) {
            cache = scan()
            loadedAt = now
        }
        cache
    }

    private fun scan(): List<InstalledApp> {
        val pm = appContext.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved: List<ResolveInfo> = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(launcherIntent, 0)
            }
        } catch (_: RuntimeException) {
            emptyList()
        }
        return resolved
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == appContext.packageName) return@mapNotNull null
                val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
                if (label.isBlank()) null else InstalledApp(label, pkg)
            }
            .distinctBy { it.packageName }
    }
}
