package com.acesso60.messaging

import com.acesso60.execution.AppNameMatcher

/** Uma linha da agenda: nome do contato e um dos telefones dele. */
data class ContactEntry(
    val name: String,
    val phone: String,
    val isMobile: Boolean = false,
)

/**
 * Escolhe o telefone certo para o nome dito pelo usuário. Puro Kotlin, sem Android.
 *
 * Para enviar mensagem SEM confirmação extra, errar de pessoa é pior do que pedir ajuda:
 * por isso, se o melhor nível de correspondência pegar contatos diferentes (ex.: dois "João"),
 * devolve `null` e o app cai no modo manual em vez de adivinhar.
 */
object ContactMatcher {

    /** Número ditado ("para 31 99999-8888") tem prioridade sobre qualquer busca por nome. */
    fun dictatedNumber(spoken: String): String? {
        val trimmed = spoken.trim()
        if (trimmed.isEmpty() || trimmed.any { it.isLetter() }) return null
        val digits = trimmed.filter { it.isDigit() }
        return if (digits.length >= MIN_PHONE_DIGITS) trimmed else null
    }

    fun findPhone(spoken: String, contacts: List<ContactEntry>): String? {
        dictatedNumber(spoken)?.let { return it }

        val query = AppNameMatcher.normalize(spoken)
        if (query.isEmpty()) return null
        val queryWords = query.split(' ')

        val ranked = contacts.mapNotNull { entry ->
            val name = AppNameMatcher.normalize(entry.name)
            val nameWords = name.split(' ')
            val rank = when {
                name.isEmpty() -> null
                name == query -> RANK_EXACT
                startsWithWords(nameWords, queryWords) -> RANK_PREFIX
                containsWords(nameWords, queryWords) -> RANK_WORDS
                else -> null
            }
            rank?.let { it to entry }
        }
        if (ranked.isEmpty()) return null

        val bestRank = ranked.minOf { it.first }
        val best = ranked.filter { it.first == bestRank }.map { it.second }
        val distinctPeople = best.map { AppNameMatcher.normalize(it.name) }.toSet()
        if (distinctPeople.size > 1) return null

        return (best.firstOrNull { it.isMobile } ?: best.first()).phone
    }

    private fun startsWithWords(words: List<String>, prefix: List<String>): Boolean =
        prefix.size <= words.size && prefix.indices.all { words[it] == prefix[it] }

    private fun containsWords(words: List<String>, part: List<String>): Boolean {
        if (part.isEmpty() || part.size > words.size) return false
        return (0..words.size - part.size).any { start ->
            part.indices.all { words[start + it] == part[it] }
        }
    }

    private const val MIN_PHONE_DIGITS = 8
    private const val RANK_EXACT = 0
    private const val RANK_PREFIX = 1
    private const val RANK_WORDS = 2
}
