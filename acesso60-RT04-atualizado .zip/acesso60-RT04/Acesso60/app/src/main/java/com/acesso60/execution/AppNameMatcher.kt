package com.acesso60.execution

import br.com.acesso60.core.interpreter.CommandRegistry

/**
 * Casamento tolerante entre o nome falado e o nome visível de um app instalado.
 * Puro Kotlin (sem Android), coberto por testes de unidade.
 *
 * Ordem de preferência: nome idêntico > nome do app começa com o que foi dito > o que foi dito aparece
 * como palavras seguidas dentro do nome. Em empate vence o nome mais curto
 * (assim "youtube" abre "YouTube" e não "YouTube Music").
 */
object AppNameMatcher {

    /** Minúsculas, sem acento, sem pontuação e com espaços simples. */
    fun normalize(value: String): String =
        CommandRegistry.normalize(value)
            .replace(NON_ALPHANUMERIC, " ")
            .replace(SPACES, " ")
            .trim()

    fun bestMatch(spoken: String, installed: List<InstalledApp>): InstalledApp? {
        val query = normalize(spoken)
        if (query.length < MIN_QUERY_LENGTH) return null
        val queryWords = query.split(' ')

        return installed
            .mapNotNull { app ->
                val label = normalize(app.label)
                val rank = when {
                    label.isBlank() -> null
                    label == query -> RANK_EXACT
                    startsWithWords(label.split(' '), queryWords) -> RANK_PREFIX
                    containsWords(label.split(' '), queryWords) -> RANK_CONTAINS
                    else -> null
                }
                rank?.let { Triple(app, it, label.length) }
            }
            .minWithOrNull(compareBy<Triple<InstalledApp, Int, Int>> { it.second }.thenBy { it.third })
            ?.first
    }

    private fun startsWithWords(words: List<String>, prefix: List<String>): Boolean =
        prefix.size <= words.size && prefix.indices.all { words[it] == prefix[it] }

    private fun containsWords(words: List<String>, part: List<String>): Boolean {
        if (part.isEmpty() || part.size > words.size) return false
        return (0..words.size - part.size).any { start ->
            part.indices.all { words[start + it] == part[it] }
        }
    }

    private const val MIN_QUERY_LENGTH = 2
    private const val RANK_EXACT = 0
    private const val RANK_PREFIX = 1
    private const val RANK_CONTAINS = 2
    private val NON_ALPHANUMERIC = Regex("[^a-z0-9]+")
    private val SPACES = Regex("\\s+")
}
