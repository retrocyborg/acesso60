package com.acesso60.messaging

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ContactMatcherTest {
    private val contacts = listOf(
        ContactEntry("João Silva", "(31) 99999-1111", isMobile = true),
        ContactEntry("João Pedro", "(31) 98888-2222", isMobile = true),
        ContactEntry("Maria", "(31) 3333-4444", isMobile = false),
        ContactEntry("Maria", "(31) 97777-5555", isMobile = true),
        ContactEntry("Minha Mãe", "(31) 96666-7777", isMobile = true),
        ContactEntry("Ana Clara", "(31) 95555-0000", isMobile = true),
    )

    @Test
    fun `nome exato ignora acento e caixa e prefere celular`() {
        assertEquals("(31) 97777-5555", ContactMatcher.findPhone("maria", contacts))
        assertEquals("(31) 96666-7777", ContactMatcher.findPhone("minha mae", contacts))
    }

    @Test
    fun `primeiro nome ambiguo entre pessoas diferentes nao adivinha`() {
        assertNull(ContactMatcher.findPhone("João", contacts))
    }

    @Test
    fun `nome completo desambigua`() {
        assertEquals("(31) 98888-2222", ContactMatcher.findPhone("joão pedro", contacts))
    }

    @Test
    fun `sobrenome casa como palavra inteira`() {
        assertEquals("(31) 95555-0000", ContactMatcher.findPhone("clara", contacts))
    }

    @Test
    fun `pedaco dentro de palavra nao casa`() {
        assertNull(ContactMatcher.findPhone("mar", contacts))
        assertNull(ContactMatcher.findPhone("", contacts))
    }

    @Test
    fun `numero ditado e usado direto`() {
        assertEquals("31 99999-8888", ContactMatcher.findPhone("31 99999-8888", contacts))
        assertNull(ContactMatcher.dictatedNumber("Maria 2"))
        assertNull(ContactMatcher.dictatedNumber("123"))
    }
}
