package com.acesso60.execution

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Registro com leitura dos APKs instalados: "abrir <qualquer app>" sem cadastro prévio. */
class InstalledAppsRegistryTest {
    private val whatsapp = AppDefinition("WhatsApp", "com.whatsapp", setOf("whatsapp", "zap"))
    private val messages = AppDefinition("Mensagens", "com.google.android.apps.messaging", setOf("mensagens", "sms"))

    private fun source(vararg apps: InstalledApp) = object : InstalledAppsSource {
        override fun list(): List<InstalledApp> = apps.toList()
    }

    private fun registry(vararg apps: InstalledApp) = StaticAppRegistry(
        provider = StaticAppDefinitionProvider(listOf(whatsapp, messages)),
        staticDefinitions = emptyList(),
        installedApps = source(*apps),
    )

    @Test
    fun `abre app instalado que nao esta no JSON pelo nome visivel`() {
        val reg = registry(InstalledApp("YouTube", "com.google.android.youtube"))

        val resolved = reg.resolve("youtube")

        assertEquals("com.google.android.youtube", resolved?.packageName)
    }

    @Test
    fun `alias do JSON vence quando o pacote esta instalado`() {
        val reg = registry(InstalledApp("WhatsApp", "com.whatsapp"), InstalledApp("Zap Mania", "com.example.zapmania"))

        assertEquals(whatsapp, reg.resolve("zap"))
    }

    @Test
    fun `definicao cujo pacote nao existe cai no app instalado com o mesmo nome`() {
        // Aparelho Samsung: o app de mensagens não é o do Google.
        val reg = registry(InstalledApp("Mensagens", "com.samsung.android.messaging"))

        assertEquals("com.samsung.android.messaging", reg.resolve("mensagens")?.packageName)
    }

    @Test
    fun `definicao conhecida mas nao instalada e devolvida para o launcher avisar nao instalado`() {
        val reg = registry(InstalledApp("YouTube", "com.google.android.youtube"))

        assertEquals(whatsapp, reg.resolve("whatsapp"))
    }

    @Test
    fun `nome desconhecido nao resolve`() {
        assertNull(registry(InstalledApp("YouTube", "com.google.android.youtube")).resolve("jogo inexistente"))
    }

    @Test
    fun `alias ignora acentos`() {
        val reg = StaticAppRegistry(listOf(AppDefinition("Camera", "com.android.camera", setOf("camera"))))

        assertEquals("Camera", reg.resolve("CÂMERA")?.id)
    }

    @Test
    fun `aliases duplicados vindos do provider nao derrubam o app`() {
        val dup = AppDefinition("Outro", "com.example.outro", setOf("whatsapp"))
        val reg = StaticAppRegistry(StaticAppDefinitionProvider(listOf(whatsapp, dup)))

        assertEquals("WhatsApp", reg.resolve("whatsapp")?.id)
    }
}
