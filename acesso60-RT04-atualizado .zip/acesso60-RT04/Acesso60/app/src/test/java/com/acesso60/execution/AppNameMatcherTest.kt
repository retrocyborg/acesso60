package com.acesso60.execution

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AppNameMatcherTest {
    private val installed = listOf(
        InstalledApp("YouTube Music", "com.google.android.apps.youtube.music"),
        InstalledApp("YouTube", "com.google.android.youtube"),
        InstalledApp("Google Play Store", "com.android.vending"),
        InstalledApp("Câmera", "com.samsung.android.camera"),
        InstalledApp("WhatsApp Business", "com.whatsapp.w4b"),
        InstalledApp("WhatsApp", "com.whatsapp"),
    )

    @Test
    fun `nome identico vence mesmo havendo nomes mais longos que comecam igual`() {
        assertEquals("com.google.android.youtube", AppNameMatcher.bestMatch("youtube", installed)?.packageName)
        assertEquals("com.whatsapp", AppNameMatcher.bestMatch("WhatsApp", installed)?.packageName)
    }

    @Test
    fun `ignora acento e caixa`() {
        assertEquals("com.samsung.android.camera", AppNameMatcher.bestMatch("camera", installed)?.packageName)
        assertEquals("com.samsung.android.camera", AppNameMatcher.bestMatch("CÂMERA", installed)?.packageName)
    }

    @Test
    fun `parte do nome em palavras inteiras tambem casa`() {
        assertEquals("com.android.vending", AppNameMatcher.bestMatch("play store", installed)?.packageName)
        assertEquals("com.google.android.apps.youtube.music", AppNameMatcher.bestMatch("youtube music", installed)?.packageName)
    }

    @Test
    fun `texto dentro de outra palavra nao casa`() {
        assertNull(AppNameMatcher.bestMatch("tube", installed))
        assertNull(AppNameMatcher.bestMatch("app inexistente", installed))
    }

    @Test
    fun `consulta vazia ou de uma letra nao abre nada`() {
        assertNull(AppNameMatcher.bestMatch("", installed))
        assertNull(AppNameMatcher.bestMatch("  ", installed))
        assertNull(AppNameMatcher.bestMatch("y", installed))
    }
}
