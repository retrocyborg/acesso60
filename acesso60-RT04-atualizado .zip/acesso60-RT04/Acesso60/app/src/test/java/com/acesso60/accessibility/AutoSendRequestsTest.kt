package com.acesso60.accessibility

import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoSendRequestsTest {
    private var now = 1_000L

    init {
        AutoSendRequests.clock = { now }
        AutoSendRequests.cancel()
    }

    @After
    fun tearDown() {
        AutoSendRequests.cancel()
        AutoSendRequests.clock = { System.nanoTime() / 1_000_000L }
    }

    @Test
    fun `sem pedido armado nenhuma janela e clicada`() {
        assertFalse(AutoSendRequests.isArmedFor("com.whatsapp"))
    }

    @Test
    fun `pedido vale so para o pacote esperado`() {
        AutoSendRequests.arm("com.whatsapp")

        assertTrue(AutoSendRequests.isArmedFor("com.whatsapp"))
        assertFalse(AutoSendRequests.isArmedFor("com.example.banco"))
        assertFalse(AutoSendRequests.isArmedFor(null))
    }

    @Test
    fun `um clique por pedido`() {
        AutoSendRequests.arm("com.whatsapp")
        AutoSendRequests.complete()

        assertFalse(AutoSendRequests.isArmedFor("com.whatsapp"))
    }

    @Test
    fun `pedido vence depois do tempo limite`() {
        AutoSendRequests.arm("com.whatsapp", timeoutMs = 5_000L)
        now += 4_999L
        assertTrue(AutoSendRequests.isArmedFor("com.whatsapp"))
        now += 2L
        assertFalse(AutoSendRequests.isArmedFor("com.whatsapp"))
    }
}
