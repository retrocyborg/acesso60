package com.acesso60.messaging

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MessageUrisTest {
    @Test
    fun `numero nacional ganha codigo do Brasil`() {
        assertEquals("5531999991111", MessageUris.toInternationalDigits("(31) 99999-1111"))
        assertEquals("553133334444", MessageUris.toInternationalDigits("31 3333-4444"))
    }

    @Test
    fun `numero com mais ou 00 e preservado`() {
        assertEquals("14155550123", MessageUris.toInternationalDigits("+1 415 555 0123"))
        assertEquals("351912345678", MessageUris.toInternationalDigits("00351 912 345 678"))
        assertEquals("5531999991111", MessageUris.toInternationalDigits("+55 31 99999-1111"))
    }

    @Test
    fun `zero de tronco e removido e numero curto e rejeitado`() {
        assertEquals("5531999991111", MessageUris.toInternationalDigits("031 99999-1111"))
        assertNull(MessageUris.toInternationalDigits("1234"))
    }

    @Test
    fun `link do whatsapp codifica o texto com percent20`() {
        assertEquals(
            "https://api.whatsapp.com/send?phone=5531999991111&text=Chego%20em%2010%20minutos%20%26%20j%C3%A1",
            MessageUris.whatsappChat("5531999991111", "Chego em 10 minutos & já"),
        )
    }
}
