package com.acesso60.accessibility

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SendButtonMatcherTest {
    @Test
    fun `reconhece botao de envio do whatsapp e do google mensagens por id`() {
        assertTrue(SendButtonMatcher.matches("com.whatsapp:id/send", null, null))
        assertTrue(SendButtonMatcher.matches("com.whatsapp.w4b:id/send", null, null))
        assertTrue(SendButtonMatcher.matches("com.google.android.apps.messaging:id/send_message_button_icon", null, null))
    }

    @Test
    fun `reconhece pelo rotulo exato ignorando acento e caixa`() {
        assertTrue(SendButtonMatcher.matches(null, null, "Enviar"))
        assertTrue(SendButtonMatcher.matches(null, "ENVIAR SMS", null))
        assertTrue(SendButtonMatcher.matches(null, null, "Send"))
    }

    @Test
    fun `nao clica em botoes parecidos`() {
        assertFalse(SendButtonMatcher.matches("com.whatsapp:id/send_media", null, "Enviar arquivo"))
        assertFalse(SendButtonMatcher.matches(null, "Enviar localização", null))
        assertFalse(SendButtonMatcher.matches(null, null, null))
        assertFalse(SendButtonMatcher.matches("com.whatsapp:id/entry", "Digite uma mensagem", null))
    }
}
