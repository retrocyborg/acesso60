package com.acesso60.messaging

import br.com.acesso60.core.model.Command
import br.com.acesso60.core.model.ExecutionResult
import br.com.acesso60.core.screen.ScreenReadOutcome
import com.acesso60.accessibility.AccessibilityGateway
import com.acesso60.execution.ReadScreenCommandHandler
import com.acesso60.execution.SendMessageCommandHandler
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SendMessageHandlerTest {

    private val command = Command.SendMessage("João", "whatsapp", "Chego em 10 minutos")

    private class FakeLauncher(private val result: MessageLaunchResult) : MessageLauncher {
        val launched = mutableListOf<Command.SendMessage>()
        override fun launch(command: Command.SendMessage): MessageLaunchResult {
            launched += command
            return result
        }
    }

    @Test
    fun `contato achado com acessibilidade ativa envia sozinho`() {
        val launcher = FakeLauncher(MessageLaunchResult.Started(autoSend = true, contactFound = true))
        val result = SendMessageCommandHandler(launcher).handle(command)

        assertEquals(ExecutionResult.Success("Enviando mensagem para João no WhatsApp."), result)
        assertEquals(listOf(command), launcher.launched)
    }

    @Test
    fun `contato achado sem acessibilidade pede o toque final e explica por que`() {
        val launcher = FakeLauncher(MessageLaunchResult.Started(autoSend = false, contactFound = true))
        val message = (SendMessageCommandHandler(launcher).handle(command) as ExecutionResult.Success).message

        assertTrue(message.contains("toque em enviar"))
        assertTrue(message.contains("acessibilidade"))
    }

    @Test
    fun `contato nao encontrado abre o app com o texto e pede para escolher`() {
        val launcher = FakeLauncher(MessageLaunchResult.Started(autoSend = false, contactFound = false))
        val message = (SendMessageCommandHandler(launcher).handle(command) as ExecutionResult.Success).message

        assertTrue(message.contains("Não encontrei João"))
        assertTrue(message.contains("toque em enviar"))
    }

    @Test
    fun `app nao instalado vira Unavailable e falha vira Failure sem expor detalhes`() {
        assertEquals(
            ExecutionResult.Unavailable,
            SendMessageCommandHandler(FakeLauncher(MessageLaunchResult.NotInstalled)).handle(command),
        )
        val failure = SendMessageCommandHandler(FakeLauncher(MessageLaunchResult.Failed("detalhe interno"))).handle(command)
        assertTrue(failure is ExecutionResult.Failure)
        assertFalse((failure as ExecutionResult.Failure).error.contains("detalhe interno"))
    }

    @Test
    fun `app fora da allowlist nunca chega ao launcher`() {
        val launcher = FakeLauncher(MessageLaunchResult.Started(autoSend = true, contactFound = true))
        val result = SendMessageCommandHandler(launcher).handle(Command.SendMessage("João", "youtube", "oi"))
        assertEquals(ExecutionResult.Unavailable, result)
        assertTrue(launcher.launched.isEmpty())
    }

    @Test
    fun `leitura de tela bloqueada vira Denied e texto vazio e informado`() {
        fun gateway(outcome: ScreenReadOutcome) = object : AccessibilityGateway {
            override fun performBack() = false
            override fun performHome() = false
            override fun readScreen() = outcome
        }
        assertEquals(
            ExecutionResult.Denied,
            ReadScreenCommandHandler(gateway(ScreenReadOutcome.Blocked("APP_SENSIVEL_BLOQUEADO"))).handle(Command.ReadScreen),
        )
        assertEquals(
            ExecutionResult.Unavailable,
            ReadScreenCommandHandler(gateway(ScreenReadOutcome.Unavailable)).handle(Command.ReadScreen),
        )
        val text = ReadScreenCommandHandler(gateway(ScreenReadOutcome.Text(listOf("Maria", "Oi")))).handle(Command.ReadScreen)
        assertEquals(ExecutionResult.Success("Maria. Oi"), text)
    }
}
