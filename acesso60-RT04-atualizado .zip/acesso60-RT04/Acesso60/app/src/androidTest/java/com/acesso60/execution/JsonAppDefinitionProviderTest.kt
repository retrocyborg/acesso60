package com.acesso60.execution

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.delay
import org.junit.Assert.*
import org.junit.Test

/**
 * Testes básicos para [JsonAppDefinitionProvider] usando a nova factory suspensa.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class JsonAppDefinitionProviderTest {
    private val context: Context = ApplicationProvider.getApplicationContext()

    @Test
    fun providerLoadsAssetDefinitionsWhenNoFileExists() = runBlocking {
        // Sem arquivo salvo, a lista base vem dos assets (app_definitions.json), que inclui YouTube e WhatsApp.
        val file = JsonAppDefinitionProvider.storageFile(context)
        if (file.exists()) file.delete()

        val provider = JsonAppDefinitionProvider.create(context)

        assertTrue(provider.apps.any { it.packageName == "com.google.android.youtube" })
        assertTrue(provider.apps.any { it.packageName == "com.whatsapp" })
    }

    @Test
    fun addOrUpdatePersistsDataAfterDebounceDelay() = runBlocking {
        val provider = JsonAppDefinitionProvider.create(context)
        provider.addOrUpdate(com.acesso60.execution.AppDefinition("com.example", listOf("example")))
        // Wait for debounce period
        delay(provider.persistDelayMs)
        // Verify file was written
        assertTrue(JsonAppDefinitionProvider.storageFile(context).exists())
    }
}
